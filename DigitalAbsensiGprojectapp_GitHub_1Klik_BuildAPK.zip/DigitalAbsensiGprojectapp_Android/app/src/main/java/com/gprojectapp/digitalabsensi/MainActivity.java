package com.gprojectapp.digitalabsensi;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;
import java.util.ArrayList;
import java.util.Locale;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 4101;
    private WebView webView;
    private SpeechRecognizer speechRecognizer;
    private boolean listening = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new VoiceBridge(), "AndroidVoice");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendJsError("Pengenalan suara tidak tersedia. Pastikan Google/Gboard Voice Input tersedia dan aktif di HP.");
            return;
        }
        stopSpeech(false);
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { listening = true; sendJsStatus("🎙️ Mendengarkan... sebutkan nomor ABSN atau nama."); }
            @Override public void onBeginningOfSpeech() { sendJsStatus("🎙️ Suara terdeteksi..."); }
            @Override public void onRmsChanged(float rmsdB) { }
            @Override public void onBufferReceived(byte[] buffer) { }
            @Override public void onEndOfSpeech() { listening = false; sendJsStatus("🔎 Memproses suara..."); }
            @Override public void onError(int error) {
                listening = false;
                String msg;
                switch (error) {
                    case SpeechRecognizer.ERROR_AUDIO: msg = "Masalah mikrofon."; break;
                    case SpeechRecognizer.ERROR_CLIENT: msg = "Pengenalan suara dihentikan oleh sistem."; break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: msg = "Izin mikrofon belum diberikan."; break;
                    case SpeechRecognizer.ERROR_NETWORK: msg = "Jaringan bermasalah."; break;
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: msg = "Koneksi jaringan timeout."; break;
                    case SpeechRecognizer.ERROR_NO_MATCH: msg = "Suara tidak dikenali. Ucapkan nomor ABSN atau nama dengan jelas."; break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: msg = "Pengenalan suara sedang digunakan aplikasi lain."; break;
                    case SpeechRecognizer.ERROR_SERVER: msg = "Server pengenalan suara bermasalah."; break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: msg = "Tidak ada suara. Silakan coba lagi."; break;
                    default: msg = "Gagal mengenali suara (kode " + error + ").";
                }
                sendJsError(msg);
                destroyRecognizer();
            }
            @Override public void onResults(Bundle results) {
                listening = false;
                ArrayList<String> texts = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (texts != null && !texts.isEmpty()) sendJsResult(texts.get(0));
                else sendJsError("Tidak ada hasil suara.");
                destroyRecognizer();
            }
            @Override public void onPartialResults(Bundle partialResults) { }
            @Override public void onEvent(int eventType, Bundle params) { }
        });

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "id-ID");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        try {
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            sendJsError("Tidak dapat memulai mikrofon: " + e.getMessage());
            destroyRecognizer();
        }
    }

    private void stopSpeech(boolean notify) {
        if (speechRecognizer != null) {
            try { speechRecognizer.stopListening(); } catch (Exception ignored) { }
            destroyRecognizer();
        }
        listening = false;
        if (notify) sendJsStatus("⏹️ Voice dihentikan.");
    }

    private void destroyRecognizer() {
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); } catch (Exception ignored) { }
            try { speechRecognizer.destroy(); } catch (Exception ignored) { }
            speechRecognizer = null;
        }
    }

    private void sendJsResult(String text) {
        final String js = "window.onAndroidVoiceResult(" + JSONObject.quote(text == null ? "" : text) + ");";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }
    private void sendJsError(String text) {
        final String js = "window.onAndroidVoiceError(" + JSONObject.quote(text == null ? "" : text) + ");";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }
    private void sendJsStatus(String text) {
        final String js = "window.onAndroidVoiceStatus(" + JSONObject.quote(text == null ? "" : text) + ");";
        if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startSpeech();
            else sendJsError("Izin mikrofon diperlukan untuk Voice Absen. Buka Pengaturan > Aplikasi > Digital Absensi > Izin > Mikrofon.");
        }
    }

    public class VoiceBridge {
        @JavascriptInterface public void startListening() { runOnUiThread(() -> startSpeech()); }
        @JavascriptInterface public void stopListening() { runOnUiThread(() -> stopSpeech(true)); }
    }

    @Override protected void onDestroy() {
        stopSpeech(false);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
